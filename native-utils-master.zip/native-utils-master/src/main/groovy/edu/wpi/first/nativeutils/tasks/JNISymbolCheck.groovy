package edu.wpi.first.nativeutils.tasks

import org.gradle.api.DefaultTask

public class JNISymbolCheck extends DefaultTask { }