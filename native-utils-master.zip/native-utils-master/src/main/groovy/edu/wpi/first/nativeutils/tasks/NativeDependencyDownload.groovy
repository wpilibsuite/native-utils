package edu.wpi.first.nativeutils.tasks

import org.gradle.api.tasks.Copy

public class NativeDependencyDownload extends Copy { }