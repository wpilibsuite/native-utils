package edu.wpi.first.nativeutils.tasks

import org.gradle.api.DefaultTask

public class JNIHeaders extends DefaultTask { }